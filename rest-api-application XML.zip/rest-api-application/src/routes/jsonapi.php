<?php
    use Psr\Http\Message\ServerRequestInterface as Request;
    use Psr\Http\Message\ResponseInterface as Response;

    require 'C:\xampp\htdocs\rest-api-application\vendor\autoload.php';
   
    function message ($code,$status,$message,$type=null,$object=null) {
        if ($object == null) {
            return array("code" => $code, "status" => $status, "message" => $message);
        } else {
            return array("code" => $code, "status" => $status, "message" => $message, $type => $object);
        }        
    }

    $app = new \Slim\App;
    /**
     * route - CREATE - add new student - POST method
     */
    $app->post
    (
        '/api/entrevoisin', 
        function (Request $request, Response $old_response) {
            try {
                $params = $request->getQueryParams();                
                $name = $params['name'];
                $number = $params['number'];
                $adress = $params['adress'];
                $about = $params['about'];

                $sql = "insert into voisins (name,number,adress,about) values (:name,:number,:adress,:about)";

                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();

                $statement = $db_connection->prepare($sql);                
                $statement->bindParam(':name', $name);
                $statement->bindParam(':number', $number);
                $statement->bindParam(':adress', $adress);
                $statement->bindParam(':about', $about);
                $statement->execute();
                
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message(200, 'OK', "The student has been created successfully.")));
            } catch (Exception $exception) {
                
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message(500, 'KO', $exception->getMessage())));
            }

            return $response;
        }
    );

    /**
     * route - READ - get student by id - GET method
     */
    $app->get
    (
        '/api/entrevoisin/{id}', 
        function (Request $request, Response $old_response) {
            try {
                $id = $request->getAttribute('id');                

                $sql = "select * from voisins where id = :id";

                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();

                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();

                $statement = $db_connection->prepare($sql);
                $statement->execute(array(':id' => $id));
                if ($statement->rowCount()) {
                    $etudiant = $statement->fetch(PDO::FETCH_OBJ);                    
                    $body->write(json_encode(message(200, 'OK', "Process Successed.", "etudiant", $etudiant)));
                }
                else
                {
                    $body->write(json_encode(message(513, 'KO', "The student with id = '".$id."' has not been found or has already been deleted.")));
                }

                $db_access->releaseConnection();
            } catch (Exception $exception) {
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message(500, 'KO', $exception->getMessage())));
            }
            
            return $response;
        }
    );

    /**
     * route - READ - get all students - GET method
     */
    $app->get
    (
        '/api/entrevoisins', 
        function (Request $request, Response $old_response) {
            try {
                $sql = "Select * From voisins";
                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();
    
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();

                $statement = $db_connection->query($sql);
                if ($statement->rowCount()) {
                    $vosi = $statement->fetchAll(PDO::FETCH_OBJ);                    
                    $body->write(json_encode(message(200, 'OK', "Process Successed.", "vosi", $vosi)));
                } else {
                    $body->write(json_encode(message(512, 'KO', "No student has been recorded yet.")));
                }

                $db_access->releaseConnection();
            } catch (Exception $exception) {
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message(500, 'KO', $exception->getMessage())));
            }
    
            return $response;
        }
    );

    /**
     * route - UPDATE - update a student by id - PUT method
     */
    $app->put
    (
        '/api/entrevoisin/{id}', 
        function (Request $request, Response $old_response) {
            try {

                $id = $request->getAttribute('id');

                $params = $request->getQueryParams();
                $name = $params['name'];
                $number = $params['number'];
                $adress = $params['adress'];
                $about = $params['about'];

                $sql = "update voisins set name = :name, number = :number, adress = :adress, about = :about where id = :id ";

                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();

                $statement = $db_connection->prepare($sql);
                $statement->bindParam(':name', $name);
                $statement->bindParam(':number', $number);
                $statement->bindParam(':adress', $adress);
                $statement->bindParam(':about', $about);
                $statement->bindParam(':id', $id);
                $statement->execute();

                $db_access->releaseConnection();

                $response = $old_response->withHeader('Content-Type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message(200, 'OK', "Voisin modifier")));
            } catch (Exception $exception) {
                $response = $old_response->withHeader('Content-Type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message(500, 'KO', $exception->getMessage())));
            }

            return $response;
        }
    );

    /**
     * route - DELETE - delete a student by id - DELETE method
     */
    $app->delete
    (
        '/api/entrevoisin/{id}', 
        function (Request $request, Response $old_response) {
            try {
                $id = $request->getAttribute('id');

                $sql = "delete from vosins where id = :id";

                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();

                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();

                $statement = $db_connection->prepare($sql);
                $statement->execute(array(':id' => $id));

                $body->write(json_encode(message(200, 'OK', "The student has been deleted successfully.")));
                $db_access->releaseConnection();
            } catch (Exception $exception) {
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message(500, 'KO', $exception->getMessage())));
            }

            return $response;
        }
    );

    $app->put
    (
        '/api/entrevoisin/favorie/{id}', 
        function (Request $request, Response $old_response) {
            try {

                $id = $request->getAttribute('id');
                $params = $request->getQueryParams();                
                $fav = $params['fav'];

                
                $sql = "update voisins set fav = :fav where id = :id ";

                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();

                $statement = $db_connection->prepare($sql);                
                $statement->bindParam(':fav', $fav);
                $statement->bindParam(':id', $id);
                
                $statement->execute();
                
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message(200, 'OK', "Nouveau favories")));
            } catch (Exception $exception) {
                
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message(500, 'KO', $exception->getMessage())));
            }

            return $response;
        }
    );


    

    $app->run();
?>